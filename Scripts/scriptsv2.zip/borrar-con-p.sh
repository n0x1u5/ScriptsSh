#!/usr/bin/env bash
clear
rm -i $1
echo -e "Nuestro Shell Script ha terminado..."

