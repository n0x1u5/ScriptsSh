#!/usr/bin/env bash
saludo()
{
	local NOMBRE="JUAN"
	echo "En la función: Hola señor/a $NOMBRE"
}
################ PROGRAMA PRINCIPAL ############
## Declaramos las variables
NOMBRE="Ana"
clear
saludo
echo "En el programa principal: Hola señor/a $NOMBRE"


