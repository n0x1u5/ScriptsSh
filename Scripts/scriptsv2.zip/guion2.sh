#!/usr/bin/env bash
# Mi segundo Shell Scripts
clear
echo "Introduce tu nombre: "
read NOMBRE
echo Hola $NOMBRE
echo Nuestro Shell Script ha terminado...

