#!/usr/bin/env bash
# Bucle for
clear
IFS="
"
for USUARIO in `who -a`
do
	echo $USUARIO
done


