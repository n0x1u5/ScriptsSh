#!/usr/bin/env bash
clear
echo -e "Introduce el fichero a borrar: \c" 
read FICHERO
rm -i $FICHERO
echo -e "Nuestro Shell Script ha terminado..."

