#!/usr/bin/env bash
suma()
{
	let R=$1+$2
	echo "a + b = $R"
}
################ PROGRAMA PRINCIPAL ############
## Declaramos las variables
NUMERO1=56
NUMERO2=4
clear
suma $NUMERO1 $NUMERO2


