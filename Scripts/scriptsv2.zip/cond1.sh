#!/usr/bin/env bash
RUTA=/home/asir/scripts/mientras.sh
clear
if test -r $RUTA
then
	cat $RUTA
else
	echo "No existe ese fichero o no tienes permiso de lectura"
fi
echo -e "Nuestro Shell Script ha terminado..."

