#!/usr/bin/env bash
# Bucle for3
clear
SERVIDORES=/home/asir/scripts/servidores.txt
IFS="
"
for SERVIDOR in `cat $SERVIDORES`
do
	shutdown -h now $SERVIDOR
done


