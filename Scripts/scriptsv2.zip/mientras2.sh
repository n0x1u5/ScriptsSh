#!/usr/bin/env bash
# Ejemplo de while
clear
while [[ $NOMBRE != "fermin" ]]
do
	read NOMBRE
	echo -e "NOMBRE -> $NOMBRE"
	((count++))
done < nombres.txt


