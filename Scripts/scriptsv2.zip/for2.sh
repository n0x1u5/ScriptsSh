#!/usr/bin/env bash
# Bucle for2
clear
IFS="
"
for FICHERO in $(find $HOME -user root)
do
	echo $FICHERO
done


