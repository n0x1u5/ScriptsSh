#!/usr/bin/env bash
# Mi primer Shell Scripts
clear
date
ls
who
banner `date '+%D %T'`
echo Nuestro Shell Script ha terminado...




