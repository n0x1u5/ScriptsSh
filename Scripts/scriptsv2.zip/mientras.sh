#!/usr/bin/env bash
# Ejemplo de while
clear
TEXTO="ALGO"
while [ $TEXTO ]
do

	echo -e "Introduce un texto: \c" 
	read TEXTO
	echo -e "Texto -> $TEXTO"
done


